# Metro-Route-Buddy

A Java program, complete with a map that will take the source station and the destination station as an inputand display the shortest metro route to reach the destination and the fare on the basis of the total distance.

The program is implemented using Graph and Heap data structures: Nodes represent stations while edges represent the distance between the two stations.

Main algorithms used : Dijkstra, breadth-first search, depth-first search

output: 
enetered option: 1
![image](https://user-images.githubusercontent.com/83425697/183745608-93772ee7-18eb-43a9-980d-55b81e67a893.png)

and so on.....
